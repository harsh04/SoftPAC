package KDF;

import java.util.Scanner;
import org.testng.TestNG;
import org.testng.xml.XmlSuite;

public class Console {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		TestNG testngRunner = new TestNG();
		flag: while (true) {
			System.out.println("======================================");
			System.out.println("=== SoftPAC Testing Tool Framework ===");
			System.out.println("======================================\n\n");
			System.out.println("Test cases available to perform : ");
			System.out.println("1. Login");
			System.out.println("2. Membership Registration");
			System.out.println("3. Membership Modification");
			System.out.println("4. Transaction");
			System.out.println("5. Fixed Deposit");
			System.out.println("6. All Test Cases");
			System.out.println("7. Exit");
			System.out.print("\n\nEnter your choice: ");
			int response = sc.nextInt();
			switch (response) {
			case 1:
				// To run tests in Parallel mode
				//testngRunner.setParallel(XmlSuite.ParallelMode.METHODS);
				// Provide the list of test classes
				testngRunner.setTestClasses(new Class[] { KDF.Login.class });
				// Run tests
				testngRunner.run();
				break;
			case 2:
				System.out.println("	1. Individual");
				System.out.println("	2. Non - Individual");
				System.out.print("\nEnter your choice: ");
				response = sc.nextInt();
				switch(response){
				case 1:
					testngRunner.setTestClasses(new Class[] { KDF.MembershipRegistrationIndividual.class });
					testngRunner.run();
					break;
				case 2:
					System.out.println("Coming soon...");
					break;
				default:
					System.out.println("Wrong input!");
					break;
				}

				break;
			case 3:
				System.out.println("	1. Individual");
				System.out.println("	2. Non - Individual");
				System.out.println("	3. Alerts");
				System.out.print("\nEnter your choice: ");
				response = sc.nextInt();
				break;
			case 4:
				System.out.println("	1. Transaction Entry > Reciept/Payment");
				System.out.print("\nEnter your choice: ");
				response = sc.nextInt();
				break;
			case 5:
				System.out.println("	1. Create Deposit");
				System.out.println("	2. View Deposit");
				System.out.println("	3. Close Deposit");
				System.out.print("\nEnter your choice: ");
				response = sc.nextInt();
				break;

			case 7:
				System.out.println("======================================");
				break flag;

			default:
				System.out.println("Wrong input!");
				break;
			}
			System.out.println("======================================");
			System.out.print("Test another case? \"y\" or \"n\":");
			
			if(!sc.next().equalsIgnoreCase("y")){
				break flag;
			}
		}
	}

}