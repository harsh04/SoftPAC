package KDF;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String val = "70000.0";
		float in = Float.parseFloat(val);
		int dep = (int)in;
			//	int dep = Integer.parseInt(val);
		System.out.println(dep);
	}

}
