package framework;

import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.WebDriver;

public class KDTExecuter {
	
	public static void executeTest(WebDriver driver, String sheetname,
		
		HashMap<String, String> parameters, LogRecorder log) {
		Framework framework = new Framework(driver);
		Sheet KDTexcelSheet;
		
		try {
			KDTexcelSheet = ExcelFileSheet.getExcelSheet(
					"test\\resources\\data", "KDT.xlsx", sheetname);

			int KDTRowCount = KDTexcelSheet.getLastRowNum()
					- KDTexcelSheet.getFirstRowNum();

			for (int i = 1; i < KDTRowCount; i++) {
				Row row = KDTexcelSheet.getRow(i);
				if (row.getCell(0).toString().length() == 0) {
					if (row.getCell(1).toString().length() > 0) {
						try {
							String value = ExcelFileSheet.getCellValueAsString(row.getCell(4));
							if(value.contains("{{")){
								String colName = value.replace("{{", "");
								colName = colName.replace("}}", "");				
								value = parameters.get(colName);
								if(value.contains(".png")){
									value = System.getProperty("user.dir")+"\\test\\resources\\data\\images\\" +value;
								}
							}
							
							String objLocator = ExcelFileSheet.getCellValueAsString(row.getCell(2));
							if(objLocator.contains("{{")){
								String colName = objLocator.replace("{{", "");
								colName = colName.replace("}}", "");				
								objLocator = parameters.get(colName);
							}
							
							framework.performAction(ExcelFileSheet.getCellValueAsString(row.getCell(1)),
									objLocator,
									ExcelFileSheet.getCellValueAsString(row.getCell(3)),
									value,
									ExcelFileSheet.getCellValueAsString(row.getCell(5)),
									log);

						} catch (Exception e) {
							System.out.println("fail = its time to debug");
							// e.printStackTrace();
						}
					}else{
						log.rowNumber++;
						if(Framework.testCaseStatus){
							log.modifyExistingWorkbook("", "", "", "", "", "Complete Test Case Passed");
							Framework.testCaseStatus = true;
						}else{
							log.modifyExistingWorkbook("", "", "", "", "", "Test Case Failed");
							Framework.testCaseStatus = true;
						}
						
					}
				} else {
					System.out.println("New Testcase-> "
							+ row.getCell(0).toString() + " Started");
					
					log.rowNumber++;
					log.modifyExistingWorkbook("", "", "", "", "", "");
					log.rowNumber++;
					log.modifyExistingWorkbook(row.getCell(0).toString(), parameters.toString(), "", "", "", "");

				}
			}
		} catch (IOException e1) {
			System.out.println("Unable to read excel file");
		} catch (InvalidFormatException e) {
			System.out.println("Invalid file name");
		}
	}
}
