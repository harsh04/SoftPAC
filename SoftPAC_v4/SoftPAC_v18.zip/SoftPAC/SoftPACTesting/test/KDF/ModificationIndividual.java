package KDF;

import java.text.SimpleDateFormat;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import framework.*;

/**
 * this is the excel executor goes row by row of excel reads the keywords in
 * excel sheet executes one by one
 *
 */

public class ModificationIndividual {
	WebDriver driver;
	String sheetname = "ModificationIndividual";
	Sheet KDTexcelSheet;
	String strDateFormat = "dd_MM_yyyy_HH_mm_ss";
	SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);
	java.util.Date date = new java.util.Date();
	static HashMap<String, String> parameters = new HashMap<String, String>();
	
	@BeforeTest
	public void setUp() throws Exception {
		java.util.Date date = new java.util.Date();
		System.out.println("\n Start Time - "+ sdf.format(date)+"\n\n");	
		
		LogRecorder.workingDir = "test\\resources\\data\\logRecord";
		LogRecorder.fileName = "LOG_"+sheetname+"_"+sdf.format(date)+".xlsx";
		LogRecorder.sheetName = sheetname;
		LogRecorder.CreateExcel();
		
	}
	
	@DataProvider(name = "dataForTest")
	public Object[][] getLoginData() {
		return (ExcelFileSheet.readXLSX("test\\resources\\data","DDT.xlsx",sheetname));
	}
	
	@Test(dataProvider = "dataForTest")
	
	public void modificationTest(String accNumber,String Type,String accType, String fName,String mname, String lname,String gender, String dob, String religion, String occupation,String o_rate, String caste, String class_m, String nationality, String father_name, String mother_name, String pan, String form1, String form2, String voter_id, String dl, String passport, String aadhar, String add1, String add2, String village, String state, String pincode, String landline, String mobileno, String email, String income, String education, String marital_status, String other, String signature, String photo) throws Exception {
		parameters.put("accNumber", accNumber);
		parameters.put("Type", Type);
		parameters.put("AccType", accType);
		parameters.put("F_Name", fName);
		parameters.put("M_Name", mname);
		parameters.put("L_Name", lname);
		parameters.put("Gender", gender);
		parameters.put("Dob", dob);
		parameters.put("Religion", religion);
		parameters.put("Occupation", occupation);
		parameters.put("O_Rate", o_rate);
		parameters.put("Caste", caste);
		parameters.put("Class_M", class_m);
		parameters.put("Nationality", nationality);
		parameters.put("Father_Name", father_name);
		parameters.put("Mother_Name", mother_name);
		parameters.put("Pan", pan);
		parameters.put("Form60", form1);
		parameters.put("Form61", form2);
		parameters.put("VoterId", voter_id);
		parameters.put("DL", dl);
		parameters.put("Passport_Ration", passport);
		parameters.put("Aadhar", aadhar);
		parameters.put("Add1", add1);
		parameters.put("Add2", add2);
		parameters.put("Village_name", village);
		parameters.put("state", state);
		parameters.put("pincode", pincode);
		parameters.put("landline", landline);
		parameters.put("mobileno", mobileno);
		parameters.put("email", email);
		parameters.put("income", income);
		parameters.put("Education", education);
		parameters.put("Marital_status", marital_status);
		parameters.put("Other_Activity", other);
		parameters.put("signature_image", signature);
		parameters.put("signature_photo", photo);
		KDTExecuter.executeTest(driver, sheetname, parameters);
	}
	
	@AfterTest
	public void tearDown() {
		System.out.println("\n\nExecution Log - End Time - "+sdf.format(date));
		
	}
}